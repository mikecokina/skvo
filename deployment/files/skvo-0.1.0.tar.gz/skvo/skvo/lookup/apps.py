from django.apps import AppConfig


class LookupConfig(AppConfig):
    name = 'lookup'
