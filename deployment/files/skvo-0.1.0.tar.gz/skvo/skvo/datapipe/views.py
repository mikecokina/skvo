from rest_framework.response import Response

# Create your views here.
