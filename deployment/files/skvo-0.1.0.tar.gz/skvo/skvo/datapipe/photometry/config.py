NUM_VERSION = 0
VERSION = 'v{}'.format(NUM_VERSION)
TSDB_METRIC_SUFFIX = 'photometry' + '.' + VERSION
