from django.apps import AppConfig


class DatapipeConfig(AppConfig):
    name = 'datapipe'
