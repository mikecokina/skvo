from django.apps import AppConfig


class ObservationConfig(AppConfig):
    name = 'observation'
